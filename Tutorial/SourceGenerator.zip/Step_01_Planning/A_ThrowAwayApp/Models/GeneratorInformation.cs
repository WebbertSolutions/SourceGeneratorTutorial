﻿namespace A_ThrowAwayApp.Models;

public class GeneratorInformation
{
    public ClassInformation? ClassInformation { get; set; }
    public ClassInformation? InterfaceInformation { get; set; }
}
