﻿//
//	System
//
global using System.Text;

//
//	Microsoft
//


//
//	Project
//
global using MyApp.Models;


//
//	Third Party
//
global using WebbertSolutions.Generators;
global using Xunit;
