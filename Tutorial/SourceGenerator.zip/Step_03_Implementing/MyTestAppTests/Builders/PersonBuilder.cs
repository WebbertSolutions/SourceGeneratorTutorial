﻿namespace MyTestAppTests.Builders;


//[GenerateDataBuilder(typeof(Person))]
public partial class PersonBuilder
{
	//public static PersonBuilder Typical()
	//{
	//	return new PersonBuilder()
	//		.WithAddresses(AddressBuilder.GenerateAddresses(1, 3))
	//		.SetDefaultAddresses(new())
	//		;
	//}
}
