﻿//
//	System
//

global using System;
global using System.Collections.Generic;
global using System.Diagnostics;
global using System.Linq;
global using System.Text;


//
//	Microsoft
//
global using Microsoft.CodeAnalysis;
global using Microsoft.CodeAnalysis.CSharp;
global using Microsoft.CodeAnalysis.CSharp.Syntax;


//
//	Project
//

global using BaseSourceGenerator;
global using BaseSourceGenerator.Models;


//
//	Third Party
//

